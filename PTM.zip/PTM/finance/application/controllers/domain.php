<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class domain extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('uid')== '') {
			redirect(base_url());
		}
	}
	public function index() {

		
		
		$data['contant'] = $this->load->view('domain','',true);
		
		$this->load->view('master',$data);
	}
    public function autocomplete() {
        $search_data = $this->input->post('search_data');
		$offset = $this->input->post('offset')*10;
		$this->load->model('domain_model');
        $query = $this->domain_model->get_autocomplete($search_data,$offset);

        echo json_encode($query->result());
    }


}

