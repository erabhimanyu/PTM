<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class excel_insert extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('uid')== '') {
			redirect(base_url());
		}
	}
	public function index() {

/* //Excel data extraction
			$row_count = 0;
			$column_count = 0 ;
			$value1 = array();
			$file = 'C:\xampp\htdocs\BJ\finance\public\excel\name.xlsx';
			//load the excel library
			$this->load->library('excel');
			//read file from path
			$objPHPExcel = PHPExcel_IOFactory::load($file);
			//get only the Cell Collection
			$cell_collection = $objPHPExcel->getActiveSheet()->getCellCollection();
			//extract to a PHP readable array format
		foreach ($cell_collection as $cell) {
				$column = $objPHPExcel->getActiveSheet()->getCell($cell)->getColumn();
				$row = $objPHPExcel->getActiveSheet()->getCell($cell)->getRow();
				$data_value = $objPHPExcel->getActiveSheet()->getCell($cell)->getValue();
				
				
			//header will/should be in row 1 only. of course this can be modified to suit your need.
		if ($row == 1) {
				$header[$row][$column] = $data_value;
					
				
				
		} else {
				if($data_value != ""){ 
				$arr_data[$row][$column] = $data_value;
				
			 } 
			
		
			}
			}
			
			
			foreach ($arr_data as $val){
					$column_count = 0;
					foreach ($val as $v){
					
					$value1[$row_count][$column_count] = $v;
					$column_count = $column_count + 1;
					}
				$row_count= $row_count +1;
			} */
			
//Page Title
			$data['title'] = "Analysis";


			$this->load->view('master',$data);
	}
	
	
	function add_project() {
	
	//Page Title
			$data['pageTitle']="Add Project";

//Date picker helper libraries load			
			$jsurl=base_url().'public/datepicker/bootstrap-datepicker.js';
			$data['loadJs']=array($jsurl);
			$cssurl=base_url().'public/datepicker/datepicker.css';
			$data['loadCss']=array($cssurl);
			

//load the data into the master template			
			/* $data['header'] = $header;
			$data['values'] = $value1; */
			
			

//loading the model and getting the data
			$this->load->model('pre_model');
			$data['com'] = $this->pre_model->get_complexity();
			$data['task'] = $this->pre_model->get_pre_data();
			$data['activities'] = $this->pre_model->get_activities();
			$data['project_type'] = $this->pre_model->get_project_type();
//Getting the form helper libraries
			$this->load->helper('form');
			
			$data['contant']=$this->load->view('new',$data,true);
			$this->load->view('master',$data);
	
	
	}
	
	
	
//validation and saving the form	
	function pre_save(){
		// Second form validation
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		// Validating Customer Name Field
		$this->form_validation->set_rules('customer_name', 'customer_name', 'required|min_length[1]|max_length[50]');
		
		// Validating GLO field
		$this->form_validation->set_rules('GLO_number', 'GLO_number', 'required');
		// Validating PEL and other fields
		/* $this->form_validation->set_rules('PEL', 'PEL', 'required|regex_match[/^[0-9]{10}$/]'); */
		$this->form_validation->set_rules('PEL', 'PEL', 'required|min_length[1]|max_length[50]');
		
		
		$this->form_validation->set_rules('SBU', 'SBU', 'required|min_length[1]|max_length[50]');
		if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('Try Again','Validation Error');
			redirect(base_url().'excel_insert');
		}
		else {

			$this->load->model('pre_model');
			$customer_name = strtoupper($this->input->post('customer_name'));
			
			
			$GLO = $this->input->post('GLO_number');
			$PEL = $this->input->post('PEL');
			$SBU = $this->input->post('SBU');
			$PM = strtoupper($this->input->post('PM'));
			$backup_pm_pc = $this->input->post('backup_pm_pc');
			$pm_pc_2 = $this->input->post('pm_pc_2');
			$p_start = $this->input->post('p_start_date');
			$p_end = $this->input->post('p_end_date');
			$a_start = $this->input->post('p_start_date');
			$a_end = $this->input->post('a_end_date');
			
			$complex = $this->input->post('complex');
			$no_of_drops = $this->input->post('no_of_drops');
			$no_of_language = $this->input->post('no_of_languages');
			$no_of_activities = $this->input->post('no_of_activities');
			
			
			$data = array(
				'customer_name'=>$customer_name,
				'GLO'=>$GLO,
				'PEL'=>$PEL,
				'SBU'=>$SBU,
				'PM'=>$PM,
				'backup_pm_pc'=>$backup_pm_pc,
				'p_start'=>$p_start,
				'p_end'=>$p_end,
				'a_start'=>$a_start,
				'a_end'=>$a_end,
				'complexity'=>$complex,
				'no_of_drops'=>$no_of_drops,
				'no_of_languages'=>$no_of_language,
				'no_of_activities'=>$no_of_activities
						
			);
			
			$result=$this->pre_model->add_project($data);
			if($result) {
				$this->session->set_flashdata('success','Project Added successfully');
				$insert_id=$this->db->insert_id();
				redirect(base_url().'excel_insert');
			}
			else {
				$this->session->set_flashdata('error','Something went wrong. Please try again!!!');
				redirect(base_url().'excel_insert');
			}  
		}
	}
	
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */