<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class globalc extends CI_Controller {

	

}