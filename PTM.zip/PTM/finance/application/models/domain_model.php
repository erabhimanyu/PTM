
<?php
class domain_model extends CI_Model{
function __construct() {
parent::__construct();
}
   public function get_autocomplete($search_data,$offset) {
        
		$this->db->select('id');
		$this->db->select('GLO');
        $this->db->select('customer_name');
		$this->db->select('PM');
		$this->db->where('user_id', $this->session->userdata('uid'));
		$this->db->where("( GLO LIKE '".$search_data."%' OR customer_name LIKE '%".$search_data."%')");
		
	/* 	$this->db->like('GLO', $search_data, 'after');
		$this->db->or_like('customer_name',$search_data); */
		
		
		
		
		
		
		
		
		/* $array = array('GLO' => $search_data, 'user_id' => '1');
		$this->db->like($array);
		$array2 = array('customer_name'=> $search_data, 'user_id' => '1');
		$this->db->like($array2); */
        /* $this->db->like('GLO', $search_data, 'after'); */
		
		
		return $this->db->get('project_details', 10,$offset);
    }
}
?>