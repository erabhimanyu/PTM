		<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="profile.html"><img src="<?php echo base_url().'public/img/user.png'; ?>" width="60"></a></p>
              	  <h5 class="centered"><?php echo $this->session->userdata("name"); ?></h5>
              	  	
                  <li class="mt">
                      <a href="<?php echo base_url().'dashboard'; ?>">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-desktop"></i>
                          <span>Analysis</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="<?php echo base_url().'analysis/general'; ?>">General</a></li>
                           <li><a  href="<?php echo base_url().'analysis/advance'; ?>">Advance</a></li>
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="<?php echo base_url().'loan'; ?>" >
                          <i class="fa fa-cogs"></i>
                          <span>Settings</span>
                      </a>

                  </li>
                  <li class="sub-menu">
                      <a href="<?php echo base_url().'dashboard/report'; ?>" >
                          <i class="fa fa-book"></i>
                          <span>Reports</span>
                      </a>
                  </li>

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
	  
	  
	    <script>
      //custom select box
		
   /*    $(function(){
          $('select.styled').customSelect();
      });
 */
  </script>