      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="<?php echo base_url(); ?>" class="logo"><b>LioXanalytics</b></a>
            <!--logo end-->

            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="<?php echo base_url().'login/logout'; ?>">Logout</a></li>
					
					
					
							<li ><div class="dropdown" style="display: inline-block;">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Foremark
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="#">HTML</a></li>
    <li><a href="#">CSS</a></li>
    <li><a href="#">JavaScript</a></li>
  </ul>
</div></li>
            	</ul>
				
		
            </div>
			 
       
        </header>
		
		
		
