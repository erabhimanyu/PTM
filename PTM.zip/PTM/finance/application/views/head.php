<meta charset="UTF-8">
<title>
	<?php 
		if(isset($pageTitle)):
			echo $pageTitle;
		else:
			echo "Finance Manager";
		endif;
	?>
</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="<?php echo base_url().'public/css/bootstrap.css'; ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url().'public/font-awesome/css/font-awesome.css'; ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url().'public/css/ionicons.css'; ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url().'public/css/AdminLTE.css'; ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()."public/resource/dropzone/dropzone.css"; ?>" type="text/css" rel="stylesheet" />




<link href="<?php echo base_url()."public/css/style.css"; ?>" type="text/css" rel="stylesheet" />
<link href="<?php echo base_url()."public/css/style-responsive.css"; ?>" type="text/css" rel="stylesheet" />


<?php
	/*to load css in header pass url of css in $loadCss variable as array*/
	if(isset($loadCss)):
		if(is_array($loadCss)):
			foreach($loadCss as $css):
				echo '<link href="'.$css.'" rel="stylesheet" type="text/css" />';
			endforeach;
		endif;
	endif;
?>
<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
	<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->

	<script src="<?php echo base_url().'public/js/jquery.js'; ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/knockout/3.4.0/knockout-min.js"></script>
	
	
	
	<?php 
		/* to load javascript file pass url of css in $loadJs variable as array */
		if(isset($loadJs)):
			if(is_array($loadJs)):
				foreach($loadJs as $js):
					echo '<script type="text/javascript" src="'.$js.'"></script>';
				endforeach;
			endif;
		endif;
	?>
