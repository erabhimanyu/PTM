
<?php 
//Pre Calculalations
/* echo $values[1][17];

echo "<br>";
echo count($values);
echo "<br>";
$count = 0;
foreach ($values as $val){
	if ($val[1] == "1000/47" or $val[1] == "1000/48" ) {
	$count = $count + $val[17];
				}
	}
	echo  $count;
	
 */

?>
<h3><i class="fa fa-angle-right"></i>Effort Calculator</h3>
<div class="row">
<!--Area for calculation Input-->
<div class="col-md-6">
	<div class="row">
	<div class="col-md-6">
		<label>Complexity<span class="text-danger">*</span></label>
		<select class= "form-control" name="complex" id="complex">
			<?php
			if(empty($complexity)){
				echo "<option>No register Donor</option>";}
			else{
				foreach ($complexity as $c)
				{
				?>				
			<option value="<?php echo $c['weight'];?>"><?php echo "Level ",$c['level'];?></option>
				<?php }}?>
		</select>
	</div>
							<div class="col-md-6">
						<label>Project Type<span class="text-danger">*</span></label>
						<select class= "form-control" name="project_type" id="project_type">
						<?php
							if(empty($project_type)){
									echo "<option>No type added</option>";}
							else{
									foreach ($project_type as $type)
											{
												?>				
											<option value="<?php echo $type['id'];?>"><?php echo $type['type'];?></option>
											<?php }}?>
						</select>
						</div>
	<div class="col-md-12">
	<label>No. of Activities<span class="text-danger">*</span></label><br>
	<input id="no_of_activities" name="no_of_activities" class="form-control" type="text" placeholder="Enter no. of activities" required pattern="[0-9]+" readonly/>
	</div>
	<div class="col-md-12">
	<label>Select Activities<span class="text-danger">*</span></label>
		<select class="form-control" name="activities" id="activities" multiple>
			<?php 
			foreach ($activities as $act){
				if($act['project_id'] == 1){
				echo "<option value=".$act['activity'].">".$act['activity']."</option>";
				}
					}
							?>
		</select>
		</div>
		<div class="col-md-6">
						<label>No. of Drops<span class="text-danger">*</span></label><br>
						<input id="no_of_drops" name="no_of_drops" class="form-control" type="text" placeholder="Enter no. of drops" required pattern="[0-9]+"/>
		</div>
		<div class="col-md-6">
						<label>No. of Languages<span class="text-danger">*</span></label><br>
						<input id="no_of_languages" name="no_of_languages" class="form-control" type="text" placeholder="Enter no. of languages" required pattern="[0-9]+"/>
		</div>
	</div>
	</div>
	<!--Area for form output-->					
<div id="output" class="col-md-6" style="background-color: white; height: 220px; padding-right:50px;">

</div>					
</div>









		

		
		<div class="col-md-12">
			<div class="box box-warning">
				<div class="box-body">
					<div class="row">
						
					</div>
					<?php
						
						if(isset($task)) {
								$count1 = 0;
								foreach ($task as $t){
						
									$count1 = $count1 + $t['baseline'];
									}
														
								echo '<input type="hidden" id="task_count" name="task_count" value="'.$count1.'"/>';
						}						
					?>



					
					
			
						
						
						
						
						<div class="col-md-6">
						
						</div>
						
						
						
						
						
						
						
						
						
						
						

						
				

					

					</div>
				</div>
					
								
								


<script type="text/javascript">

$(document).ready(function() {
	
   
	var complex =  $("#complex").val();
	var drops =  $("#no_of_drops").val();
	var language =  $("#no_of_languages").val();
	var activity =  $("#no_of_activities").val();
	var task_count =  $("#task_count").val();
	var transaction = drops * language * activity;
	var spu = 0;
	var transaction = drops * language * activity;
	var com = [];
	var other = [];
	<?php foreach ($task as $t){
			if($t['type'] == "complex"){
			
			echo "com.push(".$t['baseline'].");";?>
				
			<?php
				}
			else {
				echo "other.push(".$t['baseline'].");";?>
			<?php }}?>
	var com_updated = com.map(function(x) { return x * complex; });
	var other_updated = other.map(function(x) { return x * transaction; });
	spu = other_updated.reduce(function(a, b) { return a + b; }, 0) + com_updated.reduce(function(a, b) { return a + b; }, 0);
	
	
	$('#output').html("<h1>SPU: " + spu + "<br>PM Efforts: " + spu/60+"</h1>");
	/* alert("SPU: " + spu + "\n PM Efforts: " + spu/60); */
	

//Complexity Change Event handler
	$('#complex').change(function() {
	complex =  $("#complex").val();
	drops =  $("#no_of_drops").val();
	language =  $("#no_of_languages").val();
	activity =  $("#no_of_activities").val();
	task_count =  $("#task_count").val();
	transaction = drops * language * activity;
	transaction = drops * language * activity;
	com_updated = com.map(function(x) { return x * complex; });
	other_updated = other.map(function(x) { return x * transaction; });
	spu = other_updated.reduce(function(a, b) { return a + b; }, 0) + com_updated.reduce(function(a, b) { return a + b; }, 0);	
	
	
	$('#output').html("<h1>SPU: " + spu + "<br>PM Efforts: " + spu/60+"</h1>");
	/* alert("SPU: " + spu + "\n PM Efforts: " + spu/60); */
	
  
	
    
});



$('#no_of_drops,#no_of_languages').keyup(function() {
    complex =  $("#complex").val();
	drops =  $("#no_of_drops").val();
	language =  $("#no_of_languages").val();
	activity =  $("#no_of_activities").val();
	task_count =  $("#task_count").val();
	transaction = drops * language * activity;
	spu = 0;
	com_updated = com.map(function(x) { return x * complex; });
	other_updated = other.map(function(x) { return x * transaction; });
	spu = other_updated.reduce(function(a, b) { return a + b; }, 0) + com_updated.reduce(function(a, b) { return a + b; }, 0);	
	
	
	
	$('#output').html("<h1>SPU: " + spu + "<br>PM Efforts: " + spu/60+"</h1>");
	
	
  
	
    
});




//Activity Multiselect Event handler
$('select[name="activities"]').change(function() {	
	//Setting the count of activities
	var count = $('#activities option:selected').length;
	$('#no_of_activities').val(count);
	
	complex =  $("#complex").val();
	drops =  $("#no_of_drops").val();
	language =  $("#no_of_languages").val();
	activity =  $("#no_of_activities").val();
	task_count =  $("#task_count").val();
	transaction = drops * language * activity;
	transaction = drops * language * activity;
	com_updated = com.map(function(x) { return x * complex; });
	other_updated = other.map(function(x) { return x * transaction; });
	spu = other_updated.reduce(function(a, b) { return a + b; }, 0) + com_updated.reduce(function(a, b) { return a + b; }, 0);	
	
	
	
	$('#output').html("<h1>SPU: " + spu + "<br>PM Efforts: " + spu/60+"</h1>");


});
	
$('select[name="project_type"]').change(function() {	
	var id = $("#project_type").val();
	
	var project_type_id;
	var PT1 = [];
	var PT2 = [];
	var PT3 = [];
	var PT4 = [];
	
	//Using php to store project activity list into respective variables
	<?php 
		foreach ($activities as $act){
			
			echo "PT".$act['project_id'].".push(\"".$act['activity']."\");";
		
		}
	
	
	?>
//Checking for different project value type and setting multiselect options accordingly
	if (id==1){
	
	$('#activities').empty();
	for (var i = 0; i < PT1.length; i++) {
			
			$('#activities').append("<option value=\"" + PT1[i] + "\">" + PT1[i] + "</option>");
	}}
	
	
	
	if (id==2){
	
	$('#activities').empty();
	for (var i = 0; i < PT2.length; i++) {
			
			$('#activities').append("<option value=\"" + PT2[i] + "\">" + PT2[i] + "</option>");
	}}
	
	if (id==3){
	
	$('#activities').empty();
	for (var i = 0; i < PT3.length; i++) {
			
			$('#activities').append("<option value=\"" + PT3[i] + "\">" + PT3[i] + "</option>");
	}}
	
	if (id==4){
	
	$('#activities').empty();
	for (var i = 0; i < PT4.length; i++) {
			
			$('#activities').append("<option value=\"" + PT4[i] + "\">" + PT4[i] + "</option>");
	}}
	
	
});

});

</script>