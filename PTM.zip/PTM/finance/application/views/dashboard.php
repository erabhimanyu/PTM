<style>
    #projectTableContainer {
        display: inline-block;
        position: relative;/*Keeps the mask within the container*/
    }
    .mask {
        display: none;/*This hides the mask*/
    }

    #mask.loading {
        display: block;
        width: 100%;
        height: 100%;
        position: absolute;
		
        z-index: 1000;/*puts on top of everything*/
        background-image: url('<?php echo base_url().'public/img/default.gif'; ?>');
        background-position: center;
        background-repeat: no-repeat;
    }
    table.loading {
        opacity: .3;
    }
</style>
<div class="row ml mt">
	<div class="col-md-6 mb">
				
					<div class="content-panel row">
                      <!--CUSTOM CHART START -->
                      <div class="border-head">
                          <h3>Project Hours</h3>
                      </div>
                      <div class="custom-bar-chart">
                          <ul class="y-axis">
                              <li><span>10.000</span></li>
                              <li><span>8.000</span></li>
                              <li><span>6.000</span></li>
                              <li><span>4.000</span></li>
                              <li><span>2.000</span></li>
                              <li><span>0</span></li>
                          </ul>
                          <div class="bar">
                              <div class="title">JAN</div>
                              <div class="value tooltips" data-original-title="8.500" data-toggle="tooltip" data-placement="top">85%</div>
                          </div>
                          <div class="bar ">
                              <div class="title">FEB</div>
                              <div class="value tooltips" data-original-title="5.000" data-toggle="tooltip" data-placement="top">50%</div>
                          </div>
                          <div class="bar ">
                              <div class="title">MAR</div>
                              <div class="value tooltips" data-original-title="6.000" data-toggle="tooltip" data-placement="top">60%</div>
                          </div>
                          <div class="bar ">
                              <div class="title">APR</div>
                              <div class="value tooltips" data-original-title="4.500" data-toggle="tooltip" data-placement="top">45%</div>
                          </div>
                          <div class="bar">
                              <div class="title">MAY</div>
                              <div class="value tooltips" data-original-title="3.200" data-toggle="tooltip" data-placement="top">32%</div>
                          </div>
                          <div class="bar ">
                              <div class="title">JUN</div>
                              <div class="value tooltips" data-original-title="6.200" data-toggle="tooltip" data-placement="top">62%</div>
                          </div>
                      </div>
                      <!--custom chart end-->
					</div><!-- /row -->	
			
	</div>
	<div class="col-md-6">
	
		<div class="row">
		<div class="col-sm-6">
    	    <div class="content-panel hero-widget">
                <div class="icon">
                     <i class="fa fa-clock-o"></i>
                </div>
                <div class="text">
                    <var>3</var>
                    <label class="text-muted">SPU</label>
                </div>
            </div>
	
		</div>
		<div class="col-sm-6">
    	    <div class="content-panel hero-widget">
                <div class="icon">
                     <i class="fa fa-star-o"></i>
                </div>
                <div class="text">
                    <var>3</var>
                    <label class="text-muted">PM Efforts</label>
                </div>
            </div>
	
		</div>
		<div class="col-md-12 mt">
		<div class="content-panel">
		<h2 class="centered">other details goes here</h2>
		</div>
		</div>
	</div>
	
	</div>
	

	
</div>


<div class="row mt">
                  <div class="col-md-12">
                      <div class="content-panel projectTableContainer">
					  <!--Loading mask for Ajax calls-->
					  <div id="mask"></div>
                          <table id="projectTable" class="table table-striped table-advance table-hover">
						  
	                  	  	  <h4><i class="fa fa-angle-right"></i>Project List</h4>
							  
							 	<a href="#" class="fa fa-fw fa-refresh" onclick="window.location.reload( true );" data-toggle="tooltip" data-placement="bottom" title="Refresh"></a>
  	<a href="#" class="fa fa-fw fa-filter" onclick="$(searchModal).modal('show');" data-toggle="tooltip" data-placement="bottom" title="Filter Data"></a>

  	<a href="<?php echo base_url().'excel_insert/add_project'; ?>" class="fa fa-fw fa-plus" data-toggle="tooltip" data-placement="bottom" title="Add New Borrower"></a>
						<div class="something">
     <input name="search_data" id="search_data" type="text" onkeyup="ajaxSearch();">
        <div id="suggestions">
            <div id="autoSuggestionsList">  
            </div>
        </div>
		
</div>
<div id='loading' data-bind="visible: isLoading">Loading...</div>


					        <hr>
                              <thead data-bind="ifnot: hasNoMembers">
                              <tr>
								<th>#</th>
                                  <th>GLO Number</th>
                                  <th class="hidden-phone">Customer name</th>
                                  <th>PM</th>
                                  <th>Status</th>
                                  
                              </tr>
                              </thead>
                             <tbody data-bind="foreach: data">
								<tr>
									<td data-bind="text: $index() + 1"></td>
									<td><a href=""  data-bind="text: GLO, attr: {href: 'project/'+id}"></a></td>
									<td data-bind="text: customer_name"></td>
									<td data-bind="text: PM"></td>
									<td><span class="label label-info label-mini">Active</span></td>
									<td>
									<button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
									<button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
									<button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>
									</td>
           
								</tr>

							</tbody>
							<tfoot >
 <tr data-bind="if: hasNoMembers">
    <td colspan="7">
        <center>No data found<center>
     </td>
</tr>
<tr data-bind="ifnot: hasNoMembers">
<td colspan="7">
<center><button id="loadMoreButton" class="btn btn-info" data-bind="click: moreProject">Load More</button></center>
</td>
</tr>
</tfoot>
                          </table>
						  <div class="container">
						 
						</div>
                      </div><!-- /content-panel -->
                  </div><!-- /col-md-12 -->
		
              </div><!-- /row -->




<!--<input type="radio" name="format" value="csv" checked> CSV<br>
<input type="radio" name="format" value="json"> JSON<br>
<input type="radio" name="format" value="form"> FORMULAE<br> -->
<br><br>
<div id="drop">Drop file here</div>
<br>
<p><input type="file" name="xlfile" id="xlf" /> ... or click here to select a file</p>
<pre id="out"></pre>
<button type="button" id="remove">Remove</button>
<br />
<!-- uncomment the next line here and in xlsxworker.js for encoding support -->
<!--<script src="dist/cpexcel.js"></script>-->
<script>
$("#remove").click(function(){
    document.getElementById("xlf").value = "";
	document.getElementById("out").innerHTML = "";
	
});
</script>
<script type="text/javascript">
		
		$( document ).ready(function() {
			viewModel.moreProject();
		});
		
		
		var offset = 0;
		//View model for project table
				
		function ViewModel() {
		var self = this;
			self.isLoading =  ko.observable(false);
			self.data = ko.observableArray();
			
			//Loading more data from the server using ajax on Load More button click
			self.moreProject = function() {
				 //Finding the value to be matched
				 var input_data = $('#search_data').val();
				   var post_data = {
                    'search_data': input_data,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>',
					'offset': offset
                };
				 	 	 
				 $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>domain/autocomplete/",
                    data: post_data,
                    success: function(data) {
                        // return success
						console.log(data);
						var json = $.parseJSON(data);
                        if (json.length > 0 && data != []) {
						
						for(var i = 0; i < json.length; i++) {
								var obj = json[i];

							self.data.push(obj);
								}
						offset = offset + 1;

                    } else {
						
						/* self.moreProject = ko.observable(false); */
						$('#loadMoreButton').prop('disabled', true);
					}
					}
                });	 
        
    };
	self.hasNoMembers = ko.computed(function(){
    return self.data().length === 0;
  },self);
	
			
				};
		var viewModel = new ViewModel();
		ko.applyBindings(viewModel);
		

		
		function ajaxSearch() {
			offset = 0;
			$('#loadMoreButton').prop('disabled', false);
		$('#mask').addClass('loading');
		viewModel.isLoading(true);
		
            var table = document.getElementById("projectTableBody");
			var input_data = $('#search_data').val();
/*             if (input_data.length == 0) {
               $("#projectTableBody").html("<tr><td colspan=\"7\"><center>No Data Found</center></td></tr>");
            } else { */

                var post_data = {
                    'search_data': input_data,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                };
				
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url(); ?>domain/autocomplete/",
                    data: post_data,
                    success: function(data) {
                        // return success
						
						var json = $.parseJSON(data);
                        if (json.length > 0 && data != []) {
						
						$("#projectTableBody").html("");
						var count = 1;
						viewModel.data(json);
						offset = offset + 1;
                         /* $(json).each(function(i,val){
						  var row = table.insertRow();
						  var cell = row.insertCell();
						  cell.innerHTML = count;
						  count = count +1;
    $.each(val,function(k,v){
         
		  var cell1 = row.insertCell();
		  cell1.innerHTML = v;
});
}); */

						}
					else {
					 viewModel.data('');
					}
                    }
                });

          /*   } */
			viewModel.isLoading(false);
			$('table,#mask').removeClass('loading');
        };
		
		
</script>
