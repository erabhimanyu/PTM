	
          	<h3><i class="fa fa-angle-right"></i>Select Tool</h3>
          	<div class="row mt">
     <div class="col-lg-12">
	
	
	<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 mb">
							<div class="product-panel-2 pn">
								
								<img src="assets/img/product.jpg" width="200" alt="">
								<br><br><br><br><br><br>
								<button id="effortButton" class="btn btn-small btn-theme04">Effort Calculator</button>
							</div>
						</div><! --/col-md-4 -->
						
						
						<div class="col-lg-4 col-md-4 col-sm-4 mb">
							<div class="product-panel-2 pn">
								
								<img src="assets/img/product.jpg" width="200" alt="">
								<br><br><br><br><br><br>
								<button id="spuButton" class="btn btn-small btn-theme04">SPU Calculator</button>
							</div>
						</div><! --/col-md-4 -->
			</div>
			
			
			</div>
			</div>
			
			
			
<script type="text/javascript">
    document.getElementById("spuButton").onclick = function () {
        location.href = "spuCalculator";
    };
	document.getElementById("effortButton").onclick = function () {
        location.href = "effortCalculator";
    };
</script>
