
<?php 
/* echo $values[1][17];

echo "<br>";
echo count($values);
echo "<br>";
$count = 0;
foreach ($values as $val){
	if ($val[1] == "1000/47" or $val[1] == "1000/48" ) {
	$count = $count + $val[17];
				}
	}
	echo  $count;
	
 */

?>

<div class="panel panel-default">
<div class="panel-heading"><h3>Add Project</h3></div>
<div class="panel-body">


	<!--<form action="<?php /* echo base_url(); */?>excel_insert/pre_save" method = "POST" enctype = "multipart/form-data" onsubmit="return validateForm()" name="mainform" id="mainform">-->
		<?php
		echo form_open('excel_insert/pre_save', array('name' => 'addform')); ?>
		<div class="col-md-12">
			<div class="box box-warning">
				<div class="box-body">
					<div class="row">
						<?php echo validation_errors(); ?>
					</div>
					<?php
						/* echo form_open('excel_insert/pre_save', array('name' => 'addform'));     */
						if(isset($task)) {
								$count1 = 0;
								foreach ($task as $t){
						
									$count1 = $count1 + $t['baseline'];
									}
														
								echo '<input type="hidden" id="task_count" name="task_count" value="'.$count1.'"/>';
						}						
					?>

					
					<div class="form-group">
						<div class="col-md-6">
						<label>Customer Name<span class="text-danger">*</span></label>
						<input class="form-control" id="customer_name" name="customer_name" type="text" placeholder="Enter customer name" required pattern="[a-zA-Z]+"/>
						</div>
						<div class="col-md-6">
						<label>GLO Number<span class="text-danger">*</span></label>
						<input class="form-control" id="GLO_number" name="GLO_number" type="text" placeholder="Enter GLO number" required pattern="[0-9]+"/>
						</div>
					</div>
					
					
					<div class="form-group">
						<div class="col-md-6">
						<label>PEL<span class="text-danger">*</span></label>
						<input class="form-control" id="PEL" name="PEL" type="text" placeholder="Enter PEL" required/>
						</div>
						<div class="col-md-6">
						<label>SBU<span class="text-danger">*</span></label>
						<input class="form-control" id="SBU" name="SBU" type="text" placeholder="Enter SBU" required/>
						</div>
						<div class="col-md-6">
						<label>PM<span class="text-danger">*</span></label>
						<input class="form-control" id="PM" name="PM" type="text" placeholder="Enter PM" required/>
						</div>
						<div class="col-md-6">
						<label>Backup PM/PC<span class="text-danger">*</span></label>
						<input class="form-control" id="backup_pm_pc" name="backup_pm_pc" type="text" placeholder="Enter backup PM/PC" required/>
						</div>
						<div class="col-md-6">
						<label>PM/PC 2</label>
						<input class="form-control" id="pm_pc_2" name="pm_pc_2" type="text" placeholder="Enter PM/PC 2(optional)"/>
						</div>
					</div>
					
					<div class="form-group">
						<div class="col-md-6">
						<label>Planned Start Date<span class="text-danger">*</span></label>
						<input type="text" class="form-control" value="" name="p_start_date" id="p_start_date" data-date-format="yyyy-mm-dd" placeholder="1990-01-01" pattern="\d{4}-\d{1,2}-\d{1,2}" required/>
						</div>
						<div class="col-md-6">
						<label>Planned End Date<span class="text-danger">*</span></label>
						<input type="text" class="form-control" value="" name="p_end_date" id="p_end_date" data-date-format="yyyy-mm-dd" placeholder="1990-01-01" pattern="\d{4}-\d{1,2}-\d{1,2}" required/>
						</div>
						<div class="col-md-6">
						<label>Actual Start Date<span class="text-danger">*</span></label>
						<input type="text" class="form-control" value="" name="a_start_date" id="a_start_date" data-date-format="yyyy-mm-dd" placeholder="1990-01-01" pattern="\d{4}-\d{1,2}-\d{1,2}" required/>
						</div>
						<div class="col-md-6">
						<label>Actual End Date<span class="text-danger">*</span></label>
						<input type="text" class="form-control" value="" name="a_end_date" id="a_end_date" data-date-format="yyyy-mm-dd" placeholder="1990-01-01" pattern="\d{4}-\d{1,2}-\d{1,2}" required/>
						</div>
					</div>
					
					
						
					<div class="form-group">
					
						<div class="col-md-6">
						<label>Project Type<span class="text-danger">*</span></label>
						<select class= "form-control" name="project_type" id="project_type">
						<?php
							if(empty($com)){
									echo "<option>No register Donor</option>";}
							else{
									foreach ($project_type as $type)
											{
												?>				
											<option value="<?php echo $type['id'];?>"><?php echo $type['type'];?></option>
											<?php }}?>
						</select>
						</div>
						
						
						
						
						<div class="col-md-6">
						<label>Select Activities<span class="text-danger">*</span></label>
						 <select class="form-control" name="activities" id="activities" multiple>
							<?php 
							foreach ($activities as $act){
								if($act['project_id'] == 1){
									echo "<option value=".$act['activity'].">".$act['activity']."</option>";
							}
							}
							?>
						</select>
						</div>
						
						
						
						
						
						
						
						
						
						
						
						<div class="col-md-6">
						<label>Complexity<span class="text-danger">*</span></label>
						<select class= "form-control" name="complex" id="complex">
						<?php
							if(empty($com)){
									echo "<option>No register Donor</option>";}
							else{
									foreach ($com as $c)
											{
												?>				
											<option value="<?php echo $c['weight'];?>"><?php echo "Level ",$c['level'];?></option>
											<?php }}?>
						</select>
						</div>
						
				
						<div class="col-md-6">
						<label>No. of Drops<span class="text-danger">*</span></label><br>
						<input id="no_of_drops" name="no_of_drops" class="form-control" type="text" placeholder="Enter no. of drops" required pattern="[0-9]+"/>
						</div>
						<div class="col-md-6">
						<label>No. of Languages<span class="text-danger">*</span></label><br>
						<input id="no_of_languages" name="no_of_languages" class="form-control" type="text" placeholder="Enter no. of languages" required pattern="[0-9]+"/>
						</div>
					
						<div class="col-md-6">
						<label>No. of Activities<span class="text-danger">*</span></label><br>
						<input id="no_of_activities" name="no_of_activities" class="form-control" type="text" placeholder="Enter no. of activities" required pattern="[0-9]+" readonly/>
						</div>
					</div>
				</div>
					
								
					<div class="modal-footer">
						<input type="submit" name="submit"  class="btn btn-primary" value="Add" style="margin-top:15px;">
					</div>	
					


					<?php
					echo form_close();
					
					
					?>
				
				</div><!-- /.box-body -->
			</div>
		</div>
	<!--</form>-->

<br><br><br><br>
</div>
</div>

<script type="text/javascript">
//Date Pickers for all inputs
$('#p_start_date').datepicker();
$('#p_end_date').datepicker();
$('#a_start_date').datepicker();
$('#a_end_date').datepicker();

$(document).ready(function() {
	

//Complexity Change Event handler
	$('select[name="complex"]').change(function() {
    var complex =  $("#complex").val();
	var drops =  $("#no_of_drops").val();
	var language =  $("#no_of_languages").val();
	var activity =  $("#no_of_activities").val();
	var task_count =  $("#task_count").val();
	var transaction = drops * language * activity;
	var spu = 0;
	<?php foreach ($task as $t){
			if($t['type'] == "complex"){
			
			echo "var ".$t['task']." = ".$t['baseline'];?>*complex;
				
			<?php
				}
			else {
				echo "var ".$t['task']." = ".$t['baseline'];?>*transaction;
			<?php }}?>
	spu = spu + <?php foreach ($task as $t) {echo " ".$t['task']." + ";}?>0;
	
	
	
	//alert("SPU: " + spu + "\n PM Efforts: " + spu/60);
	
  
	
    
});

//Activity Multiselect Event handler
$('select[name="activities"]').change(function() {	
	//Setting the count of activities
	 var count = $('#activities option:selected').length;
	$('#no_of_activities').val(count);


});
	
$('select[name="project_type"]').change(function() {	
	var id = $("#project_type").val();
	
	var project_type_id;
	var PT1 = [];
	var PT2 = [];
	var PT3 = [];
	var PT4 = [];
	
	//Using php to store project activity list into respective variables
	<?php 
		foreach ($activities as $act){
			
			echo "PT".$act['project_id'].".push(\"".$act['activity']."\");";
		
		}
	
	
	?>
//Checking for different project value type and setting multiselect options accordingly
	if (id==1){
	
	$('#activities').empty();
	for (var i = 0; i < PT1.length; i++) {
			
			$('#activities').append("<option value=\"" + PT1[i] + "\">" + PT1[i] + "</option>");
	}}
	
	
	
	if (id==2){
	
	$('#activities').empty();
	for (var i = 0; i < PT2.length; i++) {
			
			$('#activities').append("<option value=\"" + PT2[i] + "\">" + PT2[i] + "</option>");
	}}
	
	if (id==3){
	
	$('#activities').empty();
	for (var i = 0; i < PT3.length; i++) {
			
			$('#activities').append("<option value=\"" + PT3[i] + "\">" + PT3[i] + "</option>");
	}}
	
	if (id==4){
	
	$('#activities').empty();
	for (var i = 0; i < PT4.length; i++) {
			
			$('#activities').append("<option value=\"" + PT4[i] + "\">" + PT4[i] + "</option>");
	}}
	
	
});

});

</script>