

<h1>Upload Files for Analysis</h1>
<!--DropZone Form for file uplaod-->
<form action="<?php echo site_url('/analysis/upload'); ?>" class="dropzone"  id="dropzone" >
</form>
<br>
<a href="<?php echo base_url()."analysis/spuCalculator"; ?>" class="btn btn-info" role="button">Next</a>



<script src="<?php echo base_url()."public/resource/dropzone/dropzone.min.js"; ?>"></script>
<script type="text/javascript">
//Dropzone File upload configuration 
   Dropzone.options.dropzone = {
	    maxFiles: 1,
		acceptedFiles: ".xls,.xlsx,.xlsm",
		init: function() {
		this.on("maxfilesexceeded", function(file){
        alert("No more files please!");
    });
		}
    }
 </script>
