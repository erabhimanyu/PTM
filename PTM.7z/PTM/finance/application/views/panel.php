<div class="panel panel-default">
  <div class="panel-heading"><h3>Panel heading without title</h3></div>
  <div class="panel-heading">Panel heading without title</div>
  <div class="panel-body">
    Panel content
  </div>
</div>