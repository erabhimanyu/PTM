<h3><i class="fa fa-angle-right"></i>Result</h3>
<div class="row mt">
<div class="col-md-12">
<h2>Estimated Project Management Efforts (SPU): <strong><?php echo $estimated_working_efforts;?></strong></h2>
<h2>Estimated Project Management Hours : <strong><?php echo $estimated_working_hours;?></strong></h2>
<h2>Actual Project Management Hours : <strong><?php echo $actual_working_hour;?></strong></h2>
<h2>Effort Variance Hrs : <strong><?php echo $effort_variance_hours;?></strong></h2>
<h2>Effort Variance	: <strong><?php echo $effort_variance;?></strong></h2>
<h2>Schedule Variance : <strong><?php echo $schedule_variance;?></strong></h2>

</div>
</div>