<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class dashboard extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('uid')== '') {
			redirect(base_url());
		}
	}
	public function index() {
		$data['pageTitle']="Dashboard";
		$cssurl=base_url().'public/resource/sheetJS/sheetJS.css';
		$data['loadCss']=array($cssurl);
		$shimJSurl=base_url().'public/resource/sheetJS/shim.js';
		$jszipJSurl=base_url().'public/resource/sheetJS/jszip.js';
		$odsJSurl=base_url().'public/resource/sheetJS/ods.js';
		$xlsxJSurl=base_url().'public/resource/sheetJS/xlsx.js';
		$mainJSurl=base_url().'public/resource/sheetJS/main.js';
		$data['loadJs']=array($shimJSurl,$jszipJSurl,$odsJSurl,$xlsxJSurl,$mainJSurl);
		
		$this->load->model('dashboard_model');
		$data['project_list']=$this->dashboard_model->get_all_projects();
		
		$data['contant'] = $this->load->view('dashboard',$data,true);
		
		$this->load->view('master',$data);
	}
	public function report() {
			$data['pageTitle']="Report";
			$this->load->model('dashboard_model');
			$data['installment']=$this->dashboard_model->get_installment();
			$data['contant']=$this->load->view('insallment_report',$data,true);
			$this->load->view('master',$data);		
	}


}

