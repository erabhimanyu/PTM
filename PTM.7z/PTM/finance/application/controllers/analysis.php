<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class analysis extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('uid')== '') {
			redirect(base_url());
		}
	}
	public function index() {
		$data['pageTitle']="Dashboard";
		$data['contant'] = $this->load->view('analysis_general',$data,true);
		$this->load->view('master',$data);
	}
	
	public function general() {
		
		
		$data['pageTitle']="General Tools";
		
		$data['contant'] = $this->load->view('analysis_general',$data,true);
		$this->load->view('master',$data);
		
		
	}
	
	public function advance() {
		$data['pageTitle']="General Tools";
		$data['contant'] = $this->load->view('analysis_advance',$data,true);
		$this->load->view('master',$data);
		
		}
		
	public function spuCalculator() {
		
		
		$row_count = 0;
		$column_count = 0;
		$value1 = array();
		
		
		$data['pageTitle']="SPU Calculator";
		$this->load->model('pre_model');
		
		
		$row = $this->pre_model->get_project_upload();
		if ($row == 0){
			$data['contant'] = $this->load->view('dropzone_view','',true);
			
		}
		else{
			
			$filename = $this->pre_model->get_filename();
			$file = 'C:\xampp\htdocs\PTM\finance\uploads\\'.$filename[0]['filename'];
			//load the excel library
			$this->load->library('excel');
			//read file from path
			$objPHPExcel = PHPExcel_IOFactory::load($file);
			//get only the Cell Collection
			$cell_collection = $objPHPExcel->getActiveSheet()->getCellCollection();
			//extract to a PHP readable array format
		foreach ($cell_collection as $cell) {
				$column = $objPHPExcel->getActiveSheet()->getCell($cell)->getColumn();
				$row = $objPHPExcel->getActiveSheet()->getCell($cell)->getRow();
				$data_value = $objPHPExcel->getActiveSheet()->getCell($cell)->getValue();
				
				
			//header will/should be in row 1 only. of course this can be modified to suit your need.
		if ($row == 1) {
				$header[$row][$column] = $data_value;
					
				
				
		} else {
				if($data_value != ""){ 
				$arr_data[$row][$column] = $data_value;
				
			 } 
			
		
			}
			}
			
			
			foreach ($arr_data as $val){
					$column_count = 0;
					foreach ($val as $v){
					
					$value1[$row_count][$column_count] = $v;
					$column_count = $column_count + 1;
					}
				$row_count= $row_count +1;
			} 
			
			
			
			$count = 0;
				foreach ($value1 as $val){
			if ($val[1] == "1000/47" or $val[1] == "1000/48" ) {
				$count = $count + $val[17];
				}
			}
			$data['actual_working_hour'] = $count;
			$project = $this->pre_model->get_project_details();
			$pre_data =$this->pre_model->get_pre_data();
			$complexity=$this->pre_model->get_complexity_weight($project[0]['complexity']);
			$count =0;
			foreach ($pre_data as $pre){
				if($pre['type']=="complex"){
					$count = $count + $pre['baseline']*$complexity[0]['weight'];
				}
				else{
					$count = $count + $pre['baseline']*$project[0]['no_of_drops']*$project[0]['no_of_activities']*$project[0]['no_of_languages'];
				}
				
			}
						
			$data['estimated_working_efforts']=$count;
			$data['estimated_working_hours']=$count/60;
			$data['schedule_variance'] = abs(weekdayCalculator($project[0]['p_start'],$project[0]['p_end'])- weekdayCalculator($project[0]['a_start'],$project[0]['a_end']));
			$data['effort_variance_hours'] = abs($data['estimated_working_hours'] - $data['actual_working_hour']);
			$data['effort_variance'] = ($data['effort_variance_hours']*$data['estimated_working_hours'])/100;
			
			$data['contant'] = $this->load->view('SpuCalculator',$data,true);
		
		}
				
		$this->load->view('master',$data);
		
		}
		
		
		
	public function effortCalculator() {
		$data['pageTitle']="General Tools";
		$this->load->model('pre_model');
		$data['complexity']=$this->pre_model->get_complexity();
		$data['activities']=$this->pre_model->get_activities();
		$data['project_type']=$this->pre_model->get_project_type();
		$data['task']=$this->pre_model->get_pre_data();
		$data['contant'] = $this->load->view('effortCalculator',$data,true);
		$this->load->view('master',$data);
		
		}
		
		
		
	public function upload() {
        if (!empty($_FILES)) {
        $tempFile = $_FILES['file']['tmp_name'];
        $fileName = $_FILES['file']['name'];
        $targetPath = getcwd() . '/uploads/';
        $targetFile = $targetPath . $fileName ;
        move_uploaded_file($tempFile, $targetFile);
		// if you want to save in db,where here
        // with out model just for example
        $this->load->database(); // load database
        $this->db->insert('project_files',array('project_id' => $this->session->userdata('project_id'),'filename' => $fileName));
		
			
        }
    }
	
}

