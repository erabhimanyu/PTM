
<?php
class domain_model extends CI_Model{
function __construct() {
parent::__construct();
}
   public function get_autocomplete($search_data) {
        $this->db->select('GLO');
        $this->db->select('customer_name');
		$this->db->select('PM');
        $this->db->like('GLO', $search_data, 'after');
		$this->db->or_like('customer_name', $search_data); 
        return $this->db->get('project_details', 10,0);
    }
}
?>